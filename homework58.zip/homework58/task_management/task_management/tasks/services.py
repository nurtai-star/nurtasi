from django.db import connection

def open_tasks_with_bug():
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT * FROM tasks_task
            WHERE status != 'completed'
            AND (title LIKE '%bug%' COLLATE NOCASE OR task_type = 'bug')
        """)
        rows = cursor.fetchall()
    
    return rows
